<?php

namespace MyNamespace;

class MyClass
{
    public function sayHello()
    {
        echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>Hello from MyClass!\n";
    }
}