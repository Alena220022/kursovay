<?php
include('../sections/header.php');
session_start();
echo '<br><br><br><br><br><br>';
if (isset($_POST['login'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];
  $query = $connect->prepare("SELECT * FROM users WHERE email=:email");
  $query->bindParam("email", $email, PDO::PARAM_STR);
  $query->execute();
  $result = $query->fetch(PDO::FETCH_ASSOC);
  if (!$result) {
    echo "<script>sweet_true('error','Неверные почта или пароль');console.log('1');</script>";;
  } else {
    if (password_verify($password, $result['password'])) {
      $_SESSION['id'] = $result['id'];
      $_SESSION['name'] = $result['name'];
      $_SESSION['role'] = $result['role'];
      $_SESSION['email'] = $result['email'];
      echo "<div class=\"alert\">Поздравляем, вы прошли авторизацию!</div>
                    <script>window.location = 'account.php';</script>";
    } else {
      echo "<script>console.log('Неверные данные!');</script>";
    }
  }
}
?>

<section class="form_inputs">
  <h1>Вход</h1>

  <form method="post" action="">
    <div class="form_row"><label for="email_user">почта</label> <input type="email" name="email" id="login-email" placeholder="Alena@gmail.com" required></div>
    <div class="form_row"><label for="password_user">Пароль</label> <input type="password" name="password" id="password_user" placeholder="*********" required></div>
    <button type="submit" name="login" value="login">Войти</button>
    <a href="register.php">Вы еще не зарегистрированы?</a>
    <a href="index.php">На главную</a>
  </form>

</section>