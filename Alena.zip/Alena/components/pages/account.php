<?php
session_start();

include '../sections/header.php';



function readDB($query, $connect)
{
  $query = $connect->prepare($query);
  $query->execute();
  return $query->fetchAll(PDO::FETCH_ASSOC);
}
?>


<section class="sections_general marg-top-100">
  <h2 class="header_account">Личный кабинет</h2>
  <div class="account_panels">
    <div class="account_left_panel">
      <div id="orders-tab" class="your_orders account_left_panel_block"><img src="/assets/images/accounts/orders.svg" alt="">Ваши заказы</div>
      <div id="favorites-tab" class="your_faworites account_left_panel_block"><img src="/assets/images/accounts/heart.svg" alt="">Избранное</div>
      <div id="settings-tab" class="your_settings account_left_panel_block"><img src="/assets/images/accounts/setting.svg" alt="">Настройки</div>
    </div>

    <div class="account_right_panel">
      <main>
        <div id="orders">



          <?php
          $tours = readDB('SELECT * FROM tours', $connect);
            $orders = readDB('SELECT * FROM orders WHERE user_id = ' . $_SESSION['id'], $connect);
            for ($i = 0; $i < count($tours); $i++) {
              for ($id = 0; $id < count($orders); $id++) {
                if ($tours[$i]['id'] == $orders[$id]['tour_id']) {
                  echo '
                  <div class="tour" id="delFav' . $tours[$i]['id'] . '">
                    <div class="tour_page"><img src="' . $tours[$i]['photo'] . '" alt=""></div>
                      <div class="tour_text">
                        <div class="tour_text_name">
                          <h3>' . $tours[$i]['country'] . ', ' . $tours[$i]['city'] . '</h3>
                          <span>☆☆☆</span>
                        </div>
                        <div class="tour_text_description">
                          <p>' . $tours[$i]['heading'] . '</p>
                          <span>' . $tours[$i]['description'] . '</span>
                        </div>
                      </div>
                      <div class="tour_price">
                        <p class="p_price_fiftyProcents">Дата вылета: ' . date('d.m.20y', strtotime($orders[$id]['date_begin'])) . '</p>
                        <p class="p_price_fiftyProcents">Длительность: 20 дней</p>
                        <p class="p_price_fiftyProcents">Стоимость ' . $tours[$i]['price_for_day'] * 20 . ' р</p>
                        <button onclick="addTour(' . $tours[$i]['id'] . ', \'delete\')">Отказаться</button>
                      </div>
                    </div>
                ';
                }
              }
            }
          ?>



        </div>
        <div id="favorites" style="display: none;">
          <?php
          $tours = readDB('SELECT * FROM tours', $connect);
          if (isset($_SESSION['id'])) {
            $orders = readDB('SELECT * FROM favourites WHERE user_id = ' . $_SESSION['id'], $connect);
            for ($i = 0; $i < count($tours); $i++) {
              for ($id = 0; $id < count($orders); $id++) {
                if ($tours[$i]['id'] == $orders[$id]['id_tour']) {
                  echo '
                  <div class="tour">
                    <div class="tour_page"><img src="' . $tours[$i]['photo'] . '" alt=""></div>
                      <div class="tour_text">
                        <div class="tour_text_name">
                          <h3>' . $tours[$i]['country'] . ', ' . $tours[$i]['city'] . '</h3>
                          <span>☆☆☆</span>
                        </div>
                        <div class="tour_text_description">
                          <p>' . $tours[$i]['heading'] . '</p>
                          <span>' . $tours[$i]['description'] . '</span>
                        </div>
                      </div>
                      <div class="tour_price">';
                  if (isset($_SESSION['id'])) {
                    echo '<div class="tour_price_favourites" onclick="fetchData(' . $tours[$i]['id'] . ',)">
                                    <img id="addFavI' . $tours[$i]['id'] . '" src="/assets/images/tours/heart.svg" alt="">
                                    <p id="addFavP' . $tours[$i]['id'] . '">Отменить</p>
                                  </div>';
                  }
                  echo '
                        <p class="p_price">' . $tours[$i]['price_for_day'] * 20 . ' р</p>
                        <button onclick="addTour(' . $tours[$i]['id'] . ', \'add\')">Заказать</button>
                        <span>Тур заказан ' . $tours[$i]['total_orders'] . ' раз</span>
                      </div>
                    </div>
                ';
                }
              }
            }
          }
          ?>
        </div>
        <div id="settings" style="display: none;">
          Здесь будут настройки пользователя
        </div>
      </main>
    </div>

  </div>

</section>


<?
include '../sections/footer.php';
?>












<script>
  function addTour(data, action) {
    // Создаем объект XMLHttpRequest
    var xhr = new XMLHttpRequest();

    // Устанавливаем метод POST и URL для отправки запроса
    xhr.open("POST", "../controllers/orderController.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    // Определяем обработчик события, который будет вызван при завершении запроса
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
        // Обработка данных, полученных от сервера
        var response = xhr.responseText;
        console.log(response);

      }
      if (action == 'delete') {
        var delFav = document.getElementById('delFav' + data);
        console.log(delFav);
        delFav.style = "display: none;";
      }
    };

    // Отправляем запрос, передавая данные
    xhr.send("data=" + data + "&action=" + action);

  }


  function fetchData(data) {
    // Создаем объект XMLHttpRequest
    var xhr = new XMLHttpRequest();
    var addFavP = document.getElementById('addFavP' + data);
    var addFavI = document.getElementById('addFavI' + data);

    // Устанавливаем метод POST и URL для отправки запроса
    xhr.open("POST", "../controllers/favouriteController.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    // Определяем обработчик события, который будет вызван при завершении запроса
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
        // Обработка данных, полученных от сервера
        var response = xhr.responseText;
        console.log(response);

      }
    };

    addFavP.textContent = 'Тур больше не в избранном';
    addFavI.src = "/assets/images/tours/heartOnClick.svg";
    // Отправляем запрос, передавая данные
    xhr.send("data=" + data + "&action=delete");
  }



  const divs = document.querySelectorAll('.account_left_panel_block');
  let currentDiv = null; // Храним ссылку на текущий div

  document.getElementById("orders-tab").addEventListener("click", function(event) {
    event.preventDefault(); // Предотвращаем переход по ссылке
    showTab("orders");
  });

  document.getElementById("favorites-tab").addEventListener("click", function(event) {
    event.preventDefault(); // Предотвращаем переход по ссылке
    showTab("favorites");
  });

  document.getElementById("settings-tab").addEventListener("click", function(event) {
    event.preventDefault(); // Предотвращаем переход по ссылке
    showTab("settings");
  });

  function showTab(tabId) {
    const tabs = ["orders", "favorites", "settings"];
    tabs.forEach(tab => {
      const tabContent = document.getElementById(tab);
      if (tab === tabId) {
        tabContent.style.display = "block";
        if (tab === "orders") {
          window.location.reload();
        }
      } else {
        tabContent.style.display = "none";
      }
    });
  }



  divs.forEach((div, index) => {
    div.addEventListener('click', () => {
      if (currentDiv) {
        currentDiv.classList.remove('active'); // Убираем класс 'active' с предыдущего div
      }
      div.classList.add('active'); // Добавляем класс 'active' текущему div
      currentDiv = div; // Обновляем текущий div
    });

    // Добавляем обработчик события наведения на div
    div.addEventListener('mouseover', () => {
      if (div !== currentDiv) {
        div.classList.add('active'); // Если div не текущий, то добавляем класс 'active'
      }
    });

    // Добавляем обработчик события ухода мыши с div
    div.addEventListener('mouseout', () => {
      if (div !== currentDiv) {
        div.classList.remove('active'); // Если div не текущий, то убираем класс 'active'
      }
    });

    // Изначально первый div имеет синий цвет текста и белый фон
    if (index === 0) {
      div.classList.add('active');
      currentDiv = div;
    }
  });
</script>