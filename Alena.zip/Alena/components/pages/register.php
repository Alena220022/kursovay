<?php session_start();
include('../sections/header.php');
echo '<br><br><br><br><br><br>';
if (isset($_POST['register'])) {
  $name = $_POST['name'];
  $email = $_POST['mail'];
  $password = $_POST['password'];
  $passworddouble = $_POST['password-double'];
  $password_hash = password_hash($password, PASSWORD_BCRYPT);
  $query = $connect->prepare("SELECT email FROM users WHERE email=:email");
  $query->bindParam(":email", $email, PDO::PARAM_STR);
  $query->execute();
  $result = $query->fetch(PDO::FETCH_ASSOC);
  if ($result['email'] == $email) {
    echo "<script>console.log('такая почта уже зарегистрирована!');</script>";
  } else {
    $query = $connect->prepare("INSERT INTO users(name,password,email) VALUES (:name,:password_hash,:email)");
    $query->bindParam(":name", $name, PDO::PARAM_STR);
    $query->bindParam(":password_hash", $password_hash, PDO::PARAM_STR);
    $query->bindParam(":email", $email, PDO::PARAM_STR);
    $result = $query->execute();
    if ($result) {
      echo "<script>console.log('Регистрация прошла успешно!');</script>";
      $query = $connect->prepare("SELECT * FROM users WHERE email=:email");
      $query->bindParam("email", $email, PDO::PARAM_STR);
      $query->execute();
      $result = $query->fetch(PDO::FETCH_ASSOC);
      $_SESSION['id'] = $result['id'];
      $_SESSION['name'] = $result['name'];
      $_SESSION['role'] = $result['role'];
      $_SESSION['email'] = $result['email'];
      $_SESSION['timeonline_users'] = $result['timeonline_users'];
      echo '<script>window.location = "account.php";</script>';
    } else {
      echo '<p class="error">Неверные данные!</p>';
    }
  }
}
?>

<section class="form_inputs">
  <h1>Регистрация</h1>

  <form method="post" action="">

    <div class="form_row"><label for="name_user">Имя</label> <input type="text" name="name" id="name_user" placeholder="Максим" required></div>
    <div class="form_row"><label for="email_user">Почта</label> <input type="email" name="mail" id="email_user" placeholder="Alena@gmail.com" required></div>
    <div class="form_row"><label for="password_user">Пароль</label> <input type="password" name="password" id="password_user" placeholder="*********" required></div>
    <div class="form_row"><label for="repeat_password" id="repeat_password_label">Повтор пароля</label><input type="password" name="password-double" id="repeat_password" placeholder="*********" required></div>
    <button type="submit" name="register" value="register">Зарегистрироваться</button>
    <a href="login.php">У вас уже есть аккаунт?</a>
    <a href="index.php#account_url">На главную</a>
  </form>

</section>





</body>

</html>