<?php
  session_start();
  include '../sections/header.php';

?>

<body>



  <section class="sections_general MainSelection">
    <div class="cont_glavn">
      <p>Туристические путёвки по всему миру</p>
      <a href="UsTours.php"><button>Подробнее</button></a>
    </div>
  </section>

  <section class="sections_general">
    <h2 id="btours">Горящие туры</h2>
    <div class="white_background">
      <div class="btours">

        <?php

        $tours = $connect->prepare('SELECT * FROM tours');
        $tours->execute();
        $tours = $tours->fetchAll(PDO::FETCH_ASSOC);
        for ($i = 0; $i < count($tours); $i++) {
          if ($tours[$i]['hot_tour'] == 'yes') {
            echo ' <div class="btour">
                  <div class="sale"><img src="../../assets/images/btours/Discount.svg" alt=""></div>
                  <span class="triangle"></span>
                  <span class="red_price">от 10050 р</span>
                  <img src="'.$tours[$i]['photo'].'" alt="">
                  <div class="btour_white">
                    <p><strong>'.$tours[$i]['city'].'</strong></p>
                    <div class="rating"><input type="radio" id="star-1" name="rating" value="1"><label for="star-1" title="Оценка «1»"></label><input type="radio" id="star-2" name="rating" value="2"><label for="star-2" title="Оценка «2»"></label><input type="radio" id="star-3" name="rating" value="3"><label for="star-3" title="Оценка «3»"></label><input type="radio" id="star-4" name="rating" value="4"><label for="star-4" title="Оценка «4»"></label><input type="radio" id="star-5" name="rating" value="5"><label for="star-5" title="Оценка «5»"></label></div>
                    <p><strong>'.$tours[$i]['country'].'</strong></p>
                    <p class="old_price">'.$tours[$i]['price_for_day'] * 20 .' p</p>
                  </div>
                </div>';
          }
         
        }
        ?>
      </div>
      <div>
        <button>Посмотреть больше</button>
      </div>
    </div>
  </section>



  <section class="sections_general">
    <h2 id="aboutUs">О нас</h2>
    <div class="white_background">
      <h3 class="h3-40-georg">О компании</h3>
      <p>Наша компания Travel занимается продажей туристических путёвок во множество городов и стран по всему миру. Lorem ipsum dolor sit amet consectetur. Euismod lobortis gravida interdum cras. Turpis pulvinar sed posuere pulvinar. Et est id eget odio pellentesque mi nec leo sit. Tortor purus pharetra fames ornare varius dictum. Vulputate orci consectetur ac pellentesque sapien amet euismod et. Congue elit turpis ultrices orci ac odio donec purus sed. Euismod duis condimentum tempor amet arcu volutpat.</p>
      <h3 class="h3-40-georg">Наши преимущества</h3>
      <div class="flex_father block_advantages">
        <img src="../../assets/images/aboutUs/online_border.svg" alt="">
        <img src="../../assets/images/aboutUs/payment.svg" alt="">
        <img src="../../assets/images/aboutUs/stocks_and_discounts.svg" alt="">
      </div>
    </div>
  </section>

  <section class="sections_general">
    <h2 id="review">Отзывы</h2>
    <div class="white_background">
      <div class="flex_father">
        <div class="review">
          <div class="review_head">
            <img src="../../assets/images/users/userAlena.png" alt="">
            <div class="head_stars">
              <p>Alena</p>
              <div class="rating"><input type="radio" id="star-1" name="rating" value="1"><label for="star-1" title="Оценка «1»"></label><input type="radio" id="star-2" name="rating" value="2"><label for="star-2" title="Оценка «2»"></label><input type="radio" id="star-3" name="rating" value="3"><label for="star-3" title="Оценка «3»"></label><input type="radio" id="star-4" name="rating" value="4"><label for="star-4" title="Оценка «4»"></label><input type="radio" id="star-5" name="rating" value="5"><label for="star-5" title="Оценка «5»"></label></div>

            </div>

          </div>
          <div class="review_bot">
            Лучшая компания 10 из 10 на кончиках пальцев. Ездили туда всей семьёй и поедем ещё раз. Всем рекомендую!11! Lorem ipsum dolor sit amet consectetur. Nulla nam posuere elementum elit integer felis ut mauris. Dignissim feugiat maecenas semper ac quis. Amet sit ut quis a condimentum tellus. Euismod neque mauris sit nulla nisl nulla augue consectetur urna. Quis consectetur volutpat etiam sit sollicitudin.
            Sit pharetra blandit dolor risus tristique fames. Pulvinar fames dui tempus luctus neque condimentum sit dis. Libero interdum varius tellus etiam. Justo venenatis condimentum nunc tincidunt hac lectus quis nulla arcu. Sit gravida magna orci elit elit ut sit rhoncus mauris.
          </div>
        </div>

        <div class="review">
          <div class="review_head">
            <img src="../../assets/images/users/userAlena.png" alt="">
            <p>Alena</p>
          </div>
          <div class="review_bot">
            Лучшая компания 10 из 10 на кончиках пальцев. Ездили туда всей семьёй и поедем ещё раз. Всем рекомендую!11! Lorem ipsum dolor sit amet consectetur. Nulla nam posuere elementum elit integer felis ut mauris. Dignissim feugiat maecenas semper ac quis. Amet sit ut quis a condimentum tellus. Euismod neque mauris sit nulla nisl nulla augue consectetur urna. Quis consectetur volutpat etiam sit sollicitudin.
            Sit pharetra blandit dolor risus tristique fames. Pulvinar fames dui tempus luctus neque condimentum sit dis. Libero interdum varius tellus etiam. Justo venenatis condimentum nunc tincidunt hac lectus quis nulla arcu. Sit gravida magna orci elit elit ut sit rhoncus mauris.
          </div>
        </div>
      </div>
    </div>
  </section>

  <? include '../sections/footer.php' ?>

</body>

</html>