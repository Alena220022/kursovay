<?php
session_start();
include '../sections/header.php';



function readDB($query, $connect)
{
  $query = $connect->prepare($query);
  $query->execute();
  return $query->fetchAll(PDO::FETCH_ASSOC);
}
?>


<section class="sections_general marg-top-100">
  <h2>Наши туры</h2>
  <div class="white_background searching_panel">

    <form action="">
      <label for=""></label><input name="city" type="text" placeholder="Город вылета">
      <label for=""></label><input name="" type="text" placeholder="Страна">
      <label for=""></label><input name="" type="date" placeholder="Город вылета">
      <label for=""></label><input name="" type="text" placeholder="Количество дней">
      <label for=""></label><input name="" type="text" placeholder="Город вылета">
    </form>

  </div>
  <div class="alltours marg-top-100">
    <?php
    $tours = readDB('SELECT * FROM tours', $connect);
    if (isset($_SESSION['id'])) {
      $favIdUser = readDB('SELECT * FROM favourites WHERE user_id = ' . $_SESSION['id'], $connect);
      $ordIdUser = readDB('SELECT * FROM orders WHERE user_id = ' . $_SESSION['id'], $connect);
    }
    for ($i = 0; $i < count($tours); $i++) {
      echo '
        <div class="tour">
          <div class="tour_page"><img src="' . $tours[$i]['photo'] . '" alt=""></div>
            <div class="tour_text">
              <div class="tour_text_name">
                <h3>' . $tours[$i]['country'] . ', ' . $tours[$i]['city'] . '</h3>
                <span>☆☆☆</span>
              </div>
              <div class="tour_text_description">
                <p>' . $tours[$i]['heading'] . '</p>
                <span>' . $tours[$i]['description'] . '</span>
              </div>
            </div>
            <div class="tour_price">';
      $flag = 0;
      if (isset($_SESSION['id'])) {
        for ($id = 0; $id < count($favIdUser); $id++) {
          if ($tours[$i]['id'] == $favIdUser[$id]['id_tour']) {
            echo '<div class="tour_price_favourites" onclick="console.log(\'Вы уже добавили этот тур\')">
                              <img src="/assets/images/tours/heart.svg" alt="">
                              <p>тур добавлен в избранное</p>
                            </div>';
            $flag = 1;
            break;
          }
        }
        if ($flag == 0) {
          echo '<div  class="tour_price_favourites" onclick="fetchData(' . $tours[$i]['id'] . ',)">
                                <img id="addFavI' . $tours[$i]['id'] . '" src="/assets/images/tours/heartOnClick.svg" alt="">
                                <p id="addFavP' . $tours[$i]['id'] . '">Добавить в избранное</p>
                              </div>';
        }
      } else {
        echo '<div  class="tour_price_favourites" onclick="console.log(\'Чтобы добавть тур в избранное войдите в аккаунт\')">
                                <img id="addFavI' . $tours[$i]['id'] . '" src="/assets/images/tours/heartOnClick.svg" alt="">
                                <p id="addFavP' . $tours[$i]['id'] . '">Добавить в избранное</p>
                              </div>';
      }
      echo '<p class="p_price">' . $tours[$i]['price_for_day'] * 20 . ' р</p>';
      if (isset($_SESSION['id'])) {
        $flag = 0;
        for ($id = 0; $id < count($ordIdUser); $id++) {
          if ($tours[$i]['id'] == $ordIdUser[$id]['tour_id']) {
            echo '<button style=\'background: white; border: 2px solid #0093D0; color: #0093D0; font-size;\' onclick="window.location.replace(\'account.php\')">К заказам</button>
                      ';
            $flag = 1;
            break;
          }
        }
        if ($flag == 0) {
          echo '<button onclick="addTour(' . $tours[$i]['id'] . ')">Заказать</button>
                   ';
        }
      } else {
        echo '<button onclick="addTour(' . $tours[$i]['id'] . ')">Заказать</button>
                  ';
      }
      echo '<span>Тур заказан ' . $tours[$i]['total_orders'] . ' раз</span>
      </div></div>';
    }
    ?>
  </div>
</section>
<?php
include '../sections/footer.php';
?>
</body>

<script>
  function fetchData(data) {
    // Создаем объект XMLHttpRequest
    var xhr = new XMLHttpRequest();
    var addFavP = document.getElementById('addFavP' + data);
    var addFavI = document.getElementById('addFavI' + data);
    console.log(addFavP)
    // Устанавливаем метод POST и URL для отправки запроса
    xhr.open("POST", "../controllers/favouriteController.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    // Определяем обработчик события, который будет вызван при завершении запроса
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
        // Обработка данных, полученных от сервера
        var response = xhr.responseText;
        console.log(response);

      }
    };
    addFavP.textContent = 'тур добавлен в избранное';
    addFavI.src = "/assets/images/tours/heart.svg";
    // Отправляем запрос, передавая данные
    xhr.send("data=" + data + "&action=add");
  }





  function addTour(data) {
    // Создаем объект XMLHttpRequest
    var xhr = new XMLHttpRequest();

    // Устанавливаем метод POST и URL для отправки запроса
    xhr.open("POST", "../controllers/orderController.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    // Определяем обработчик события, который будет вызван при завершении запроса
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
        // Обработка данных, полученных от сервера
        var response = xhr.responseText;
        console.log(response);
        window.location.reload();
      }
    };

    // Отправляем запрос, передавая данные
    xhr.send("data=" + data + "&action=add");
  }
</script>