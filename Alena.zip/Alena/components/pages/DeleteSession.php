<?php
session_start(); // Начинаем сессию
session_destroy();
header('refresh:0;index.php')
?>