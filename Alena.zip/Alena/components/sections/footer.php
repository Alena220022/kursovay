 <!-- Footer for all pages -->
<footer class="marg-top-100" id="footer">
    <div class="footer_blocks"><img class="footer_logo" src="/assets/images/logoWhite.svg" alt=""></div>
    <div class="footer_blocks">
      <p class="h3-40-georg">Контакты</p>
      <ul>
        <li><img src="" alt="">8 (800) 555 35 35</li>
        <li><img src="" alt="">Travel@mail.ru</li>
        <li><img src="" alt="">г. Москва ул. Ленина д. 1 офис 5</li>
      </ul>
    </div>
    <div class="footer_blocks">
      <p class="h3-40-georg">Мы в соцсетях</p>
      <ul>
        <li class="inline"><img src="/assets/images/massangers/Ok.svg" alt=""></li>
        <li class="inline"><img src="/assets/images/massangers/Vk.svg" alt=""></li>
        <li class="inline"><img src="/assets/images/massangers/Telega.svg" alt=""></li>
        <li class="inline"><img src="/assets/images/massangers/WhatsApp.svg" alt=""></li>
        <li class="inline"><img src="/assets/images/massangers/Dzen.svg" alt=""></li>
      </ul>
    </div>
  </footer>