<?php
session_start();
require_once '../controllers/ConnectionController.php';
?>

<!DOCTYPE html>
<html lang="ru">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MainPage</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
</head>

 <!-- Header for all pages -->
 <header>
    <div class="head_blocks"><a href="index.php"><img id="logo" src="../../assets/images/logo.svg" alt=""></a></div>
    <nav class="head_blocks">
      <p><a href="UsTours.php">Наши&nbsp;туры</a></p>
      <p><a href="index.php#btours">Горящие&nbsp;туры</a></p>
      <p><a href="index.php#aboutUs">О&nbsp;нас</a></p>
      <p><a href="index.php#review">Отзывы</a></p>
      <p><a href="index.php#footer">Контакты</a></p>
    </nav>
    <?php
      if ($_SERVER['REQUEST_URI'] == '/components/pages/account.php') {
        echo '<div ><button><a href="DeleteSession.php">Выйти</a></button></div>';
      } else if (isset($_SESSION['role'])) {
        echo '<div><button><a href="account.php">Личный кабинет</a></button></div>';
      } else {
        echo '<div ><button><a href="register.php">Вход и регистрация</a></button></div>';
      }
    ?>
    
  </header>

 