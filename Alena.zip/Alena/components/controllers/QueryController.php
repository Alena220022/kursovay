<?php



namespace MyNamespace;

class allquery {

  public $query = 'a';

  public function cons() {
    echo 'console.log("Работает")';
  }
}

