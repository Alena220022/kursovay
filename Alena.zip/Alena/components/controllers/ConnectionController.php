<?php
  //Подключение к базе данных

  $host = '127.0.0.1';
  $dbname = 'travel';
  $user = 'root';
  $pass = '';

  try {
      // Создаем объект PDO
      $connect = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);

      // Включаем режим отображения ошибок в режиме исключений
      $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $e) {
      // В случае ошибки выводим сообщение об ошибке
      echo "Server: Ошибка подключения: " . $e->getMessage();
  }