<?php
session_start();
require_once '../controllers/ConnectionController.php';
// Получаем данные из POST-запроса
$data = $_POST['data'];
$action = $_POST['action'];
if (isset($_SESSION['id'])) {

  $id = $_SESSION['id'];
  $datestart = date('y-m-d',strtotime(date('y-m-d'))+ 2592000);
  $dateEnd = date('y-m-d',strtotime($datestart)+ 2592000);
  try {
    if ($action === 'add') {
      $query = $connect->prepare("SELECT COUNT(*) FROM orders WHERE user_id=:user_id and tour_id=:tour_id");
      $query->bindParam(":user_id", $id, PDO::PARAM_STR);
      $query->bindParam(":tour_id", $data, PDO::PARAM_STR);
      $query->execute();
      $query = $query->fetchAll(PDO::FETCH_ASSOC);
      if ($query[0]['COUNT(*)'] > 0) {
        echo 'Вы уже забронировали этот тур';
      } else {
        $query = $connect->prepare("INSERT INTO orders(date_begin, date_end, user_id, tour_id) VALUES (:date_begin, :date_end, :user_id, :tour_id)");
        $query->bindParam(":date_begin", $datestart, PDO::PARAM_STR);
        $query->bindParam(":date_end", $dateEnd, PDO::PARAM_STR);
        $query->bindParam(":user_id", $id, PDO::PARAM_STR);
        $query->bindParam(":tour_id", $data, PDO::PARAM_STR);
        $query->execute();
        echo 'Тур забронирован';
      }
      
    } else if ($action === 'delete') {
      $query = $connect->prepare("DELETE from orders WHERE tour_id=$data and user_id=$id;");
      $query->execute();
      echo 'Вы больше не состоите в туре';
    }
    
  } catch (PDOException $e) {
    // В случае ошибки базы данных, вы можете получить код ошибки из исключения
    $errorCode = $e->getCode();
    if ($errorCode == 23000) {
      echo 'Вы уже добавили этот тур.';
    }
  }
} else {
  echo 'Войдите в аккаунт, чтобы забронировать тур';
}
