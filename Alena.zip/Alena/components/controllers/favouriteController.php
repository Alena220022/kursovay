<?php
session_start();
require_once '../controllers/ConnectionController.php';
// Получаем данные из POST-запроса
$data = $_POST['data'];
$action = $_POST['action'];
if (isset($_SESSION['id'])) {

  $id = $_SESSION['id'];


  try {
    if ($action === 'add') {
      $query = $connect->prepare("INSERT INTO favourites(id_tour, user_id) VALUES (:data, :user_id)");
      $query->bindParam(":data", $data, PDO::PARAM_STR);
      $query->bindParam(":user_id", $id, PDO::PARAM_STR);
      $query->execute();
      echo 'Тур добавлен в избранное';
    } else if ($action === 'delete') {
      $query = $connect->prepare("DELETE FROM `favourites` WHERE id_tour=$data and user_id=$id");
      $query->execute();
      echo 'Тур больше не в избранном';
    }
    
  } catch (PDOException $e) {
    // В случае ошибки базы данных, вы можете получить код ошибки из исключения
    $errorCode = $e->getCode();
    if ($errorCode == 23000) {
      echo 'Вы уже добавили этот тур.';
    }
  }
} else {
  echo 'Войдите в аккаунт, чтобы добавить тур в избранное';
}
